﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-58M2VQU\SQLEXPRESS;Database=Medicines;Integrated Security=True;Encrypt=False";
    }
}
