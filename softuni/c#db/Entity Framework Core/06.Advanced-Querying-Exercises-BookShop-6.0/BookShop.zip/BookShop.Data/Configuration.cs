﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=DESKTOP-58M2VQU\\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
